using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Quit_Method : MonoBehaviour
{ 
    public void quit(){
        Application.Quit(); 
    }
  
}
